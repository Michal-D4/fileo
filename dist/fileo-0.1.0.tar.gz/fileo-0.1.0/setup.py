# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['fileo', 'fileo.core', 'fileo.ui', 'fileo.widgets']

package_data = \
{'': ['*'], 'fileo': ['qss/*']}

install_requires = \
['apsw>=3.40.1.0,<4.0.0.0',
 'loguru>=0.6.0,<0.7.0',
 'pypdf2>=3.0.1,<4.0.0',
 'pyqt6>=6.4.0,<7.0.0',
 'qtawesome>=1.2.2,<2.0.0']

setup_kwargs = {
    'name': 'fileo',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Fileo\n\nThis application is about the files, your files.\n\nFileo[fɑɪlɔ] - could be FileOrganizer, but that doesn\'t matter.\n\nThe graphical interface is shown in the image below.\n\n![fileo](img/fileo.jpg)\n\n## The GUI elements:\n\n1. the application mode\n2. the menu button to hide/show the left pane widgets: folders, tags, file extensions, authors\n3. the name of current file\n4. menu button to select which fields will be visible in the file list\n5. the name of the current database\n6. the branch of folder tree from the root to the current folder\n7. the left toolbar, it contains the following buttons from top to bottom:\n   1. button to chose/create the data base file\n   2. selection of the "DIR" mode of application, the file list shows the files from the current folder\n   3. selection of the "FILTER" mode, the list of files shows the files according to the filter settings\n   4. open the filter settings dialog, switch application into "FILTER_SETUP" mode\n   5. open dialog to scan the file system to load files into the database\n   6. hide/show left pane\n   7. menu button   &mdash;\xa0  do nothing yet\n8. the dialog to start scan the file system folders for files\n9. the panel to show/edit file data: comments(notes), tags, authors(for books), locations - the folder branches where the current file can be found - file may reside in the several folders.\n\nThe application works in three main modes: DIR, FILTER and FILTER_SETUP. In DIR mode, files are selected by the current directory in the "Folders" widget.\n\nIn the FILTER mode, the list of files depends on the parameters of the filter set in FILTER_SETUP mode.\n\n## How it\'s done\n\nAs said, the app is about files. Files have a number of attributes:\n\n1. name\n2. path, the user will almost never see it, only by opening a directory or copying the full filename and in the "File info" page\n3. extension\n4. tags\n5. rating\n6. author(s) - usually for books\n7. dates\n   1. modified\n   2. opened\n   3. created\n   4. published (books)\n8. rating\n9. how many times the file has been opened\n10. size\n11. pages - usually for books\n\nThe following attributes are used in filter: all dates (but only one can be used at a time), extension, tags, rating, authors, and folder which was intentionally not included in the file attributes.\n\nFolders are not associated with file system directories, the path is used for that. You can freely create, move, copy and delete folders in the folder tree, the files will remain intact. You can, for example, create multiple folder hierarchies, this can be handy. Of course, if you delete all folders it will be impossible to access files using folder tree, but they remain accessible by filter. The next time the **`@@Lost`** folder will appear, it can be used to access files that are not in any other folder.\nYou can also copy/move files from one folder to another. **Copying** is carried out by dragging *with the left mouse button pressed*, **moving** - *with the left mouse button and Shift key pressed*.\n\n## How it works\n\n### How to add files?\n\nThere are two method to add files:\n\n1. Open "Search for files..." dialog with the button ![image-20230210145215938](img/image-20230210145215938.png)\n\n   ![image-20230210145404623](img/image-20230210145404623.png)\n\n2. drag files from the file explorer (or similar application) to the folder in the folder tree.\n\n> **Note**. Scanning the file system can be quite lengthy, so it is performed in a separate thread.\n> The red circle in the lower left corner is a sign that the thread is working:\n>\n> ![image-20230213184306153](img/image-20230213184306153.png)\n>\n> Only one thread can run at time. The user interface is not blocking but you should avoid to perform operation that make changes in the database, for example, drag-drop operations. But you can change the list of files by changing a current folder or filter, or you can open files.\n\n3. You can export the selected files (with all their attributes) from one database using the file list context menu\n\n   ![export-files](img/export-files.jpg)\n\n   and then import them to another database\n\n   ![import-files](img/import-files.jpg)\n\n   to the folder "New folder" in this case.\n\n### How to work with filters\n\nFirstly you should setup the filter:\n\n![image-20230213185910924](img/image-20230213185910924.png)\n\nWith filter defined on the picture the file list will include files from folders `DB`, `ML` and `Rust`, that has at least one of tags `Math`, `ML` or `package`, has rating greater than 4, and opened after `2022-09-14`.\n\n> **Note** Here "after" and "before" include the date in the input fields 2022-09-14 and 2022-11-14. That is, if "after"and "before" are equal then the filter includes files with a date equal to this date.\n\nThe Apply button applies a specified filter without closing the Filter Setup dialog box.\n\nThe button Done applies a filter, closing dialog and switch application into "Filter mode". In this mode when you change selection in one of the widgets in the left pane (Folders, Tags, Extensions, Authors) the list of files is changing accordingly.\n\n### How to make notes to the file\n\n![fileo-comments](img/fileo-comments.jpg)\n\n1. "+"  plus button - add new note and open it in the editor\n6. "x" button - delete the note\n8.  the button to open the note in the editor\n\n#### Note editor\n\n![edit-comment](C:\\Users\\mihal\\OneDrive\\Documents\\pyprj\\fileo\\img\\edit-comment.jpg)\n\n1. the save changes button\n2. the button to discard changes\n\nNote is a markdown text.',
    'author': 'mihal.d44',
    'author_email': 'mihal.d44@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
